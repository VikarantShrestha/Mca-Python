a=int(input("enter value of a : "))
b=int(input("enter value of b : "))

a=a+b
b=a-b
a=a-b

print("interchanged value of a : ", a)
print("interchanged value of b : ", b)