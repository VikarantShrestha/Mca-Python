fahrenheit=float(input("Enter temperature in fahrenheit : "))
celcius = (fahrenheit - 32) / (9/5)
celcius = round(celcius,4)
print("Temperature in celcius : ", celcius)