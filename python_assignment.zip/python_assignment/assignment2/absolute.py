number = float(input("Enter a number: "))

absolute_value = abs(number)

print("The absolute value of", number, "is", absolute_value)