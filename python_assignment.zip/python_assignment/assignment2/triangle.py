ang1 = int(input("enter value of first angle : "))
ang2 = int(input("enter value of second angle : "))
ang3 = int(input("enter value of third angle  : "))

if ang1+ang2+ang3==180:
    print("It is an triangle")
else:
    print("It's not")