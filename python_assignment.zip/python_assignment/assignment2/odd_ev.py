num = int(input("Enter a number : "))
if num%2==0:
    print("even number")
else:
    print("odd number")