i = 0

while i <= 255:
    print(f"ASCII value {i} is {chr(i)}")
    i += 1
